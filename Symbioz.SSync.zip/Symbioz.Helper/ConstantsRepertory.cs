﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Symbioz.Helper
{
    public class ConstantsRepertory
    {
        public const decimal DOFUS_REQUIRED_VERSION = 2.29m;
        public const int DOFUS_PROTOCOL_VERSION = 1658;
        public const decimal VERSION = 0.9m;
        public const string AUTHOR = "Skinz";
        public const ConsoleColor Symbioz_COLOR1 = ConsoleColor.Cyan;
        public const ConsoleColor Symbioz_COLOR2 = ConsoleColor.DarkCyan;
        public const string VOTE_URL = "http://gaya.servegame.com/vote.php";
        public const ushort TOKEN_ID = 15714;
    }
}
