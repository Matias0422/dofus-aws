﻿namespace Symbioz.ORM
{
    public interface ITable { }
}
