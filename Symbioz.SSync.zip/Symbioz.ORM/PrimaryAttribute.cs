﻿using System;

namespace Symbioz.ORM
{
    public class PrimaryAttribute : Attribute
    {
        public PrimaryAttribute()
        { }
    }
}
