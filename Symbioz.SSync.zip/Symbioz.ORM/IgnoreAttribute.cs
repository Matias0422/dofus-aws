﻿using System;

namespace Symbioz.ORM
{
    public class IgnoreAttribute : Attribute
    {
        public IgnoreAttribute()
        { }
    }
}
