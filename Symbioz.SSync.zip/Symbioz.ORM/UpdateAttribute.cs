﻿using System;

namespace Symbioz.ORM
{
    public class UpdateAttribute : Attribute
    {
        public UpdateAttribute()
        { }
    }
}
