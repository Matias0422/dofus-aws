namespace Symbioz.Enums
{
    public enum StatsBoostTypeEnum
    {
        Strength = 10,
        Vitality,
        Wisdom,
        Chance,
        Agility,
        Intelligence
    }
}