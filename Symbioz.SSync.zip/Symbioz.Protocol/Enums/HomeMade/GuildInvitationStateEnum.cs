using System;
namespace Symbioz.Enums
{
    public enum GuildInvitationStateEnum
	{
		GUILD_INVITATION_SENT = 1,
		GUILD_INVITATION_CANCELED,
		GUILD_INVITATION_OK
	}
}
