﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shader.DofusProtocol.Enums.HomeMade
{
    public enum MapTriggersEnum
    {
        TELEPORT = 1
    }
}
