namespace Symbioz.Enums
{
    public enum SexTypeEnum
    {
        SEX_MALE,
        SEX_FEMALE
    }
}