using System;
namespace Symbioz.Enums
{
	public enum RoleEnum
	{
		None,
		Player,
		Moderator,
		GameMaster_Padawan,
		GameMaster,
		Administrator
	}
}
