﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Symbioz.Enums.HomeMade
{
    public enum MountStableEnum
    {
        InventoryToPaddockStock = 5,
        EquipedToInventory = 13,
        ToEquiped = 15,
    }
}
