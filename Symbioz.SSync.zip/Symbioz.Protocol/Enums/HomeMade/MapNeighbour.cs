using System;
namespace Symbioz.Enums
{
	public enum MapNeighbour
	{
		None,
		Right,
		Top,
		Left,
		Bottom
	}
}
