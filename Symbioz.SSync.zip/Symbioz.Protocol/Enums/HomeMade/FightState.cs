﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Symbioz.Enums.HomeMade
{
    public enum FightState
    {
        NotStarted,
        Placement,
        Fighting,
        Ended
    }
}
