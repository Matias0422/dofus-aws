

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum SubscriptionRequiredEnum
{

LIMITED_TO_SUBSCRIBER = 0,
        LIMIT_ON_JOB_XP = 1,
        LIMIT_ON_JOB_USE = 2,
        LIMIT_ON_MAP = 3,
        LIMIT_ON_ITEM = 4,
        LIMIT_ON_VENDOR = 5,
        

}

}