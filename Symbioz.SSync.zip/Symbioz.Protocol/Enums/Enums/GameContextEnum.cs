

















// Generated on 06/04/2015 18:14:40
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum GameContextEnum
{

ROLE_PLAY = 1,
        FIGHT = 2,
        

}

}