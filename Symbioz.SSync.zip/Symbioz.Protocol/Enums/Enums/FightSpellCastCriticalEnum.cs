

















// Generated on 06/04/2015 18:14:40
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum FightSpellCastCriticalEnum
{

NORMAL = 1,
        CRITICAL_HIT = 2,
        CRITICAL_FAIL = 3,
        

}

}