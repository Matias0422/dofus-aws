

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum ClientInstallTypeEnum
{

CLIENT_INSTALL_UNKNOWN = 0,
        CLIENT_BUNDLE = 1,
        CLIENT_STREAMING = 2,
        

}

}