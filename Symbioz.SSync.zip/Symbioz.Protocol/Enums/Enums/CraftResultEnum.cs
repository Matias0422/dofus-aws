

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum CraftResultEnum
{

CRAFT_IMPOSSIBLE = 0,
        CRAFT_FAILED = 1,
        CRAFT_SUCCESS = 2,
        CRAFT_NEUTRAL = 3,
        

}

}