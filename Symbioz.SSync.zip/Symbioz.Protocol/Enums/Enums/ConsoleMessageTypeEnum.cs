

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum ConsoleMessageTypeEnum
{

CONSOLE_TEXT_MESSAGE = 0,
        CONSOLE_INFO_MESSAGE = 1,
        CONSOLE_ERR_MESSAGE = 2,
        

}

}