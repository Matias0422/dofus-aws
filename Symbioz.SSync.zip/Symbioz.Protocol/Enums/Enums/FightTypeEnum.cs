







using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{
    public enum FightTypeEnum
    {
        FIGHT_TYPE_CHALLENGE,
        FIGHT_TYPE_AGRESSION,
        FIGHT_TYPE_PvMA,
        FIGHT_TYPE_MXvM,
        FIGHT_TYPE_PvM,
        FIGHT_TYPE_PvT,
        FIGHT_TYPE_PvMU,
        FIGHT_TYPE_PVP_ARENA
    }

}