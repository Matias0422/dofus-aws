

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum ServerStatusEnum
{

STATUS_UNKNOWN = 0,
        OFFLINE = 1,
        STARTING = 2,
        ONLINE = 3,
        NOJOIN = 4,
        SAVING = 5,
        STOPING = 6,
        FULL = 7,
        

}

}