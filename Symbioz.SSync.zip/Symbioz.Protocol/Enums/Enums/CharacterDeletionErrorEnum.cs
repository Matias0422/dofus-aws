

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum CharacterDeletionErrorEnum
{

DEL_ERR_NO_REASON = 1,
        DEL_ERR_TOO_MANY_CHAR_DELETION = 2,
        DEL_ERR_BAD_SECRET_ANSWER = 3,
        DEL_ERR_RESTRICED_ZONE = 4,
        

}

}