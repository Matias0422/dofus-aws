

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum UpdatableMountBoostEnum
{

STAMINA = 3,
        MATURITY = 5,
        ENERGY = 1,
        SERENITY = 2,
        LOVE = 4,
        TIREDNESS = 6,
        

}

}