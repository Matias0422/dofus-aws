

















// Generated on 06/04/2015 18:14:41
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum NicknameGeneratingFailureEnum
{

NICKNAME_GENERATOR_RETRY_TOO_SHORT = 1,
        NICKNAME_GENERATOR_UNAVAILABLE = 2,
        

}

}