

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum BuildTypeEnum
{

RELEASE = 0,
        BETA = 1,
        ALPHA = 2,
        TESTING = 3,
        INTERNAL = 4,
        DEBUG = 5,
        EXPERIMENTAL = 6,
        

}

}