

















// Generated on 06/04/2015 18:14:41
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum PartyTypeEnum
{

PARTY_TYPE_UNDEFINED = 0,
        PARTY_TYPE_CLASSICAL = 1,
        PARTY_TYPE_DUNGEON = 2,
        PARTY_TYPE_ARENA = 3,
        

}

}