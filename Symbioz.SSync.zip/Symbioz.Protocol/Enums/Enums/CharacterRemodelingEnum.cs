

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum CharacterRemodelingEnum
{

CHARACTER_REMODELING_NOT_APPLICABLE = 0,
        CHARACTER_REMODELING_NAME = 1,
        CHARACTER_REMODELING_COLORS = 2,
        CHARACTER_REMODELING_COSMETIC = 4,
        CHARACTER_REMODELING_BREED = 8,
        CHARACTER_REMODELING_GENDER = 16,
        

}

}