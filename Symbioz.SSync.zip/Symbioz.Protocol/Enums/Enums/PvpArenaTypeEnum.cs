

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum PvpArenaTypeEnum
{

ARENA_TYPE_3VS3 = 3,
        ARENA_TYPE_5VS5 = 5,
        

}

}