

















// Generated on 06/04/2015 18:14:40
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum FightDispellableEnum
{

DISPELLABLE = 1,
        DISPELLABLE_BY_DEATH = 2,
        DISPELLABLE_BY_STRONG_DISPEL = 3,
        REALLY_NOT_DISPELLABLE = 4,
        

}

}