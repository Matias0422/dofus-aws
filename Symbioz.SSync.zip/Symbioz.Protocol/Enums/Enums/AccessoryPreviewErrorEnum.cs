

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum AccessoryPreviewErrorEnum
{

PREVIEW_ERROR = 0,
        PREVIEW_COOLDOWN = 1,
        PREVIEW_BAD_ITEM = 2,
        

}

}