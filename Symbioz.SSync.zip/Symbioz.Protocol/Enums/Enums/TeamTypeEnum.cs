

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum TeamTypeEnum
{

TEAM_TYPE_PLAYER = 0,
        TEAM_TYPE_MONSTER = 1,
        TEAM_TYPE_MUTANT = 2,
        TEAM_TYPE_TAXCOLLECTOR = 3,
        TEAM_TYPE_BAD_PLAYER = 4,
        TEAM_TYPE_PRISM = 5,
        

}

}