

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum TaxCollectorStateEnum
{

STATE_COLLECTING = 0,
        STATE_WAITING_FOR_HELP = 1,
        STATE_FIGHTING = 2,
        

}

}