

















// Generated on 06/04/2015 18:14:41
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum PresetDeleteResultEnum
{

PRESET_DEL_OK = 1,
        PRESET_DEL_ERR_UNKNOWN = 2,
        PRESET_DEL_ERR_BAD_PRESET_ID = 3,
        

}

}