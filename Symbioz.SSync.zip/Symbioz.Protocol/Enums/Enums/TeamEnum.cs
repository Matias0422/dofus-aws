

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum TeamEnum
{

TEAM_CHALLENGER = 0,
        TEAM_DEFENDER = 1,
        TEAM_SPECTATOR = 2,
        

}

}