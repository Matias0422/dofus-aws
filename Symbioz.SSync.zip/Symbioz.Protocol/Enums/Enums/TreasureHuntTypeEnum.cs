

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum TreasureHuntTypeEnum
{

TREASURE_HUNT_CLASSIC = 0,
        TREASURE_HUNT_PORTAL = 1,
        TREASURE_HUNT_LEGENDARY = 2,
        

}

}