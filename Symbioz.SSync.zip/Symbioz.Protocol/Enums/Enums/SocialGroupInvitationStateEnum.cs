

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum SocialGroupInvitationStateEnum
{

SOCIAL_GROUP_INVITATION_FAILED = 0,
        SOCIAL_GROUP_INVITATION_SENT = 1,
        SOCIAL_GROUP_INVITATION_CANCELED = 2,
        SOCIAL_GROUP_INVITATION_OK = 3,
        

}

}