

















// Generated on 06/04/2015 18:14:41
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum PartStateEnum
{

PART_NOT_INSTALLED = 0,
        PART_BEING_UPDATER = 1,
        PART_UP_TO_DATE = 2,
        

}

}