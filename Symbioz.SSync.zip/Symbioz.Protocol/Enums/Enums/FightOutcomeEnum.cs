

















// Generated on 06/04/2015 18:14:40
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum FightOutcomeEnum
{

RESULT_LOST = 0,
        RESULT_DRAW = 1,
        RESULT_VICTORY = 2,
        RESULT_TAX = 5,
        RESULT_DEFENDER_GROUP = 6,
        

}

}