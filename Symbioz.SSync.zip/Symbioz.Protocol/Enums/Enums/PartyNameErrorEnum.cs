

















// Generated on 06/04/2015 18:14:41
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum PartyNameErrorEnum
{

PARTY_NAME_UNDEFINED_ERROR = 0,
        PARTY_NAME_INVALID = 1,
        PARTY_NAME_ALREADY_USED = 2,
        PARTY_NAME_UNALLOWED_RIGHTS = 3,
        PARTY_NAME_UNALLOWED_NOW = 4,
        

}

}