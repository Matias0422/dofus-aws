

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum SubEntityBindingPointCategoryEnum
{

HOOK_POINT_CATEGORY_UNUSED = 0,
        HOOK_POINT_CATEGORY_PET = 1,
        HOOK_POINT_CATEGORY_MOUNT_DRIVER = 2,
        HOOK_POINT_CATEGORY_LIFTED_ENTITY = 3,
        HOOK_POINT_CATEGORY_BASE_BACKGROUND = 4,
        HOOK_POINT_CATEGORY_MERCHANT_BAG = 5,
        HOOK_POINT_CATEGORY_BASE_FOREGROUND = 6,
        HOOK_POINT_CATEGORY_PET_FOLLOWER = 7,
        

}

}