

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum StatsUpgradeResultEnum
{

NONE = -1,
        SUCCESS = 0,
        RESTRICTED = 1,
        GUEST = 2,
        IN_FIGHT = 3,
        NOT_ENOUGH_POINT = 4,
        

}

}