

















// Generated on 06/04/2015 18:14:40
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum FightOptionsEnum
{

FIGHT_OPTION_SET_SECRET = 0,
        FIGHT_OPTION_SET_TO_PARTY_ONLY = 1,
        FIGHT_OPTION_SET_CLOSED = 2,
        FIGHT_OPTION_ASK_FOR_HELP = 3,
        

}

}