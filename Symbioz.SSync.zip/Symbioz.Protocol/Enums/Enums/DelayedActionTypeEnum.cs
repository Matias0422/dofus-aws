

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum DelayedActionTypeEnum
{

DELAYED_ACTION_DISCONNECT = 0,
        DELAYED_ACTION_OBJECT_USE = 1,
        DELAYED_ACTION_JOIN_CHARACTER = 2,
        DELAYED_ACTION_AGGRESSION_IMMUNE = 3,
        

}

}