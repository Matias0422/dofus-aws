

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum CompassTypeEnum
{

COMPASS_TYPE_SIMPLE = 0,
        COMPASS_TYPE_SPOUSE = 1,
        COMPASS_TYPE_PARTY = 2,
        COMPASS_TYPE_PVP_SEEK = 3,
        COMPASS_TYPE_QUEST = 4,
        

}

}