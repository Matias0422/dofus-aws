

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum ShortcutBarEnum
{

GENERAL_SHORTCUT_BAR = 0,
        SPELL_SHORTCUT_BAR = 1,
        

}

}