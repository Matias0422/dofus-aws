

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum AlignmentSideEnum
{

ALIGNMENT_UNKNOWN = -2,
        ALIGNMENT_WITHOUT = -1,
        ALIGNMENT_NEUTRAL = 0,
        ALIGNMENT_ANGEL = 1,
        ALIGNMENT_EVIL = 2,
        ALIGNMENT_MERCENARY = 3,
        

}

}