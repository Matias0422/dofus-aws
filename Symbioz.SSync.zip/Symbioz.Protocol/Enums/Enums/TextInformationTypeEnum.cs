

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum TextInformationTypeEnum
{

TEXT_INFORMATION_MESSAGE = 0,
        TEXT_INFORMATION_ERROR = 1,
        TEXT_INFORMATION_PVP = 2,
        TEXT_INFORMATION_FIGHT_LOG = 3,
        TEXT_INFORMATION_POPUP = 4,
        TEXT_LIVING_OBJECT = 5,
        TEXT_ENTITY_TALK = 6,
        TEXT_INFORMATION_FIGHT = 7,
        

}

}