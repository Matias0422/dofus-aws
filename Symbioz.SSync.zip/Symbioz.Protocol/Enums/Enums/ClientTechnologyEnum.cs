

















// Generated on 06/04/2015 18:14:39
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum ClientTechnologyEnum
{

CLIENT_TECHNOLOGY_UNKNOWN = 0,
        CLIENT_AIR = 1,
        CLIENT_FLASH = 2,
        

}

}