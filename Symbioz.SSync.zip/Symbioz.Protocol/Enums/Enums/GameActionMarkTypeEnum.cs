namespace Symbioz.Enums
{
    public enum GameActionMarkTypeEnum
    {
        GLYPH = 1,
        TRAP,
        WALL,
        PORTAL
    }

}