

















// Generated on 06/04/2015 18:14:40
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

    public enum GameActionMarkCellsTypeEnum
    {
        CELLS_CIRCLE = 0,
        CELLS_CROSS = 1,
        CELLS_SQUARE = 2,

    }

}