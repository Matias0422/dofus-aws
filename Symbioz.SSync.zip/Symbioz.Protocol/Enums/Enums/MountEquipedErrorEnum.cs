

















// Generated on 06/04/2015 18:14:41
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum MountEquipedErrorEnum
{

UNSET = 0,
        SET = 1,
        RIDING = 2,
        

}

}