

















// Generated on 06/04/2015 18:14:40
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum ExchangeReplayStopReasonEnum
{

STOPPED_REASON_OK = 1,
        STOPPED_REASON_USER = 2,
        STOPPED_REASON_MISSING_RESSOURCE = 3,
        STOPPED_REASON_IMPOSSIBLE_CRAFT = 4,
        

}

}