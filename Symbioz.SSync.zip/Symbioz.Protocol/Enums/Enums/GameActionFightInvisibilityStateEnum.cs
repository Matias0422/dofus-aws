

















// Generated on 06/04/2015 18:14:40
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum GameActionFightInvisibilityStateEnum
{

INVISIBLE = 1,
        DETECTED = 2,
        VISIBLE = 3,
        

}

}