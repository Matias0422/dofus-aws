

















// Generated on 06/04/2015 18:14:41
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum PrismListenEnum
{

PRISM_LISTEN_NONE = 0,
        PRISM_LISTEN_MINE = 1,
        PRISM_LISTEN_ALL = 2,
        

}

}