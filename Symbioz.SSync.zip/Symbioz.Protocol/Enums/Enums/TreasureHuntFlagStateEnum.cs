

















// Generated on 06/04/2015 18:14:42
using System;
using System.Collections.Generic;

namespace Symbioz.Enums
{

public enum TreasureHuntFlagStateEnum
{

TREASURE_HUNT_FLAG_STATE_UNKNOWN = 0,
        TREASURE_HUNT_FLAG_STATE_OK = 1,
        TREASURE_HUNT_FLAG_STATE_WRONG = 2,
        

}

}