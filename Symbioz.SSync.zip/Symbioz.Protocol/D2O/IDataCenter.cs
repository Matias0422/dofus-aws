﻿namespace Symbioz.DofusProtocol.D2O
{
    public interface IDataCenter
    {
        #region Propriétés
        string Module { get; }
        #endregion
    }
}
