![alt tag](http://image.noelshack.com/fichiers/2015/52/1450734679-logosymbioz.png)

Dofus 2.30 Emulator written in C#


Dofus 2.30 Client: https://1fichier.com/?gvw0da0veh

Just modify the config.xml with notepad and set the connection host value to: 127.0.0.1


#Some Pictures
![alt tag](http://puu.sh/oFSe3/a5aeb61441.jpg) (Working on Symbioz 2.34)
![alt tag](http://image.noelshack.com/fichiers/2016/15/1460897223-dungeonpartyfinder.png)
![alt tag](http://image.noelshack.com/fichiers/2016/15/1460897227-eliotropes.png)

#Author

Written by Skinz (https://github.com/Skinz3)

#Contributors

Mathis Cucci (https://github.com/Matspyder51)

#Thanks

LuaxY - https://github.com/LuaxY

Project under license creative commons.
